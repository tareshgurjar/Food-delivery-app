const data = [
    {
        id: 1,
        title: "Perfect Burger",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3Q8kVyo",
        price: 22,
        rating: 5,
        route: "perfect-burger"
    }
];

export default data;
