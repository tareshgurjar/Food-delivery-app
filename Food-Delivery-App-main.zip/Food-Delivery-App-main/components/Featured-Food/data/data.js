const data = [
    {
        id: 1,
        title: "Stack O'Snacks",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3oN02gp",
        price: 20,
        rating: 4,
        route: "stack-osnacks"
    },
    {
        id: 2,
        title: "Pizza",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3bqiWqr",
        price: 18,
        rating: 3,
        route: "pizza"
    },
    {
        id: 3,
        title: "Perfect Burger",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3Q8kVyo",
        price: 22,
        rating: 5,
        route: "perfect-burger"
    },
    {
        id: 4,
        title: "Taco",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3zMTKE2",
        price: 34,
        rating: 4,
        route: "taco"
    },
    {
        id: 5,
        title: "Laksa",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3zs7YIU",
        price: 45,
        rating: 3,
        route: "laksa"
    },
    {
        id: 6,
        title: "Tom Yum",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3cTZDGq",
        price: 40,
        rating: 4,
        route: "tom-yum"
    }
];

export default data;