const data = [
    {
        id: 1,
        title: "Moroccan Tajine",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3vH011x",
        price: 175,
        rating: 5
    },
    {
        id: 2,
        title: "Fruits dessert",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3bEHHPE",
        price: 115,
        rating: 3
    },
    {
        id: 3,
        title: "Asian Sushi & Fruits",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3Qrgyi9",
        price: 122,
        rating: 4
    },
    {
        id: 4,
        title: "Barbicue & Soda",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        image_url: "https://bit.ly/3zYAqne",
        price: 140,
        rating: 5
    }
];

export default data;